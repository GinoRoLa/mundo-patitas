# Sistema de Consolidación de Entregas

Este es un sistema web para registrar entregas de pedidos con fotos y datos del cliente.

## Archivos incluidos

- `consolidacion_entrega.html` - Formulario principal
- `procesar_entrega.php` - Script PHP para procesar los datos
- `database.sql` - Script para crear la base de datos
- `README.md` - Este archivo de instrucciones

## Requisitos

- Servidor web (Apache, Nginx, etc.)
- PHP 7.4 o superior
- MySQL 5.7 o superior
- Extensión PDO de PHP habilitada

## Instalación

### 1. Configurar la base de datos

1. Abre phpMyAdmin o tu cliente de MySQL
2. Ejecuta el archivo `database.sql` para crear la base de datos y tablas
3. Verifica que se haya creado la base de datos `consolidacion_entregas`

### 2. Configurar la conexión a la base de datos

Edita el archivo `procesar_entrega.php` y modifica estas líneas según tu configuración:

```php
$host = 'localhost';        // Tu servidor de base de datos
$dbname = 'consolidacion_entregas';
$username = 'root';         // Tu usuario de MySQL
$password = '';             // Tu contraseña de MySQL
```

### 3. Configurar permisos de carpeta

Crea una carpeta `uploads` en el mismo directorio que los archivos PHP y dale permisos de escritura:

```bash
mkdir uploads
chmod 777 uploads
```

### 4. Subir archivos al servidor

Sube todos los archivos a tu servidor web:
- `consolidacion_entrega.html`
- `procesar_entrega.php`
- Carpeta `uploads/` (vacía)

## Uso

1. Abre `consolidacion_entrega.html` en tu navegador
2. Completa los datos del formulario
3. Selecciona una dirección de la tabla
4. Sube las fotos requeridas (DNI y foto de entrega)
5. Haz clic en "Registrar"

## Funcionalidades

- ✅ Formulario responsivo
- ✅ Subida de imágenes
- ✅ Validación de datos
- ✅ Almacenamiento en base de datos
- ✅ Interfaz intuitiva

## Estructura de la base de datos

### Tabla `entregas`
- Almacena toda la información de cada entrega
- Incluye datos del repartidor, cliente, fotos y observaciones
- Timestamps automáticos para fecha de creación y actualización

### Tabla `pedidos` (opcional)
- Referencia de pedidos disponibles
- Puede ser utilizada para cargar dinámicamente los pedidos

## Solución de problemas

### Error de conexión a la base de datos
- Verifica que MySQL esté ejecutándose
- Confirma los datos de conexión en `procesar_entrega.php`
- Asegúrate de que el usuario tenga permisos para la base de datos

### Error al subir imágenes
- Verifica que la carpeta `uploads` exista y tenga permisos de escritura
- Confirma que PHP tenga habilitada la extensión `fileinfo`

### Formulario no envía datos
- Verifica que el archivo `procesar_entrega.php` esté en la misma carpeta
- Revisa la consola del navegador para errores de JavaScript


