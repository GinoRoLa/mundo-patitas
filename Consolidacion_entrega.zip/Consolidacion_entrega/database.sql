-- Crear base de datos
CREATE DATABASE IF NOT EXISTS consolidacion_entregas;
USE consolidacion_entregas;

-- Crear tabla de entregas
CREATE TABLE IF NOT EXISTS entregas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    repartidor_id VARCHAR(50) NOT NULL,
    repartidor_nombre VARCHAR(100) NOT NULL,
    repartidor_apellido VARCHAR(100) NOT NULL,
    distrito VARCHAR(100) NOT NULL,
    direccion_seleccionada TEXT NOT NULL,
    cliente_dni VARCHAR(20) NOT NULL,
    cliente_nombre VARCHAR(100) NOT NULL,
    cliente_apellido_paterno VARCHAR(100) NOT NULL,
    cliente_apellido_materno VARCHAR(100),
    cliente_celular VARCHAR(20),
    cliente_email VARCHAR(100),
    cliente_direccion TEXT NOT NULL,
    estado_entrega ENUM('entregado', 'no-entregado') NOT NULL,
    observaciones TEXT,
    foto_direccion VARCHAR(255),
    foto_dni VARCHAR(255),
    foto_entrega VARCHAR(255),
    pedidos_entregar JSON,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Crear tabla de pedidos (opcional, para referencia)
CREATE TABLE IF NOT EXISTS pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(50) UNIQUE NOT NULL,
    descripcion TEXT NOT NULL,
    cantidad INT NOT NULL DEFAULT 1,
    direccion TEXT NOT NULL,
    distrito VARCHAR(100) NOT NULL,
    estado ENUM('pendiente', 'asignado', 'entregado', 'no-entregado') DEFAULT 'pendiente',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insertar algunos pedidos de ejemplo
INSERT INTO pedidos (codigo, descripcion, cantidad, direccion, distrito) VALUES
('PED-00205', 'Correa extensible mediana', 2, 'Av. Naranjal 154', 'Los Olivos'),
('PED-00207', 'Galletas sin azúcar 150g', 3, 'Av. Naranjal 154', 'Los Olivos'),
('PED-00208', 'Collar de cuero', 1, 'Mz. C Lt. 10 Urb. Pro', 'Los Olivos'),
('PED-00209', 'Juguete para perro', 2, 'Av. Las Palmeras 850', 'Los Olivos');


