<?php
// Archivo para obtener direcciones y distritos de la base de datos
header('Content-Type: application/json; charset=utf-8');

// Configuración de la base de datos
$host = 'localhost';
$dbname = 'mundo_patitas3';
$username = 'root';
$password = '';

try {
    // Conexión a la base de datos
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Verificar qué tipo de consulta se está solicitando
    $tipoConsulta = isset($_GET['tipo']) ? $_GET['tipo'] : null;
    $distritoSeleccionado = isset($_GET['distrito']) ? $_GET['distrito'] : null;
    $idTrabajador = isset($_GET['idTrabajador']) ? $_GET['idTrabajador'] : null;
    
    if ($tipoConsulta === 'distritos') {
        // Consulta para obtener solo los distritos disponibles (Id_Zona = 1)
        $sql = "SELECT 
                    DescNombre
                FROM t77DistritoEnvio
                WHERE Id_Zona = 1";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $distritos = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'data' => $distritos,
            'type' => 'distritos'
        ]);
        
    } else {
        // Para obtener direcciones (todas o por distrito) se requiere idTrabajador
        if (!$idTrabajador) {
            echo json_encode([
                'success' => false,
                'message' => 'Falta el parámetro requerido: idTrabajador'
            ]);
            exit;
        }

        // Consulta base con los JOINs solicitados
        $sql = "SELECT DISTINCT
                    t77.DescNombre AS Distrito,
                    t71.DireccionSnap AS Direccion
                FROM t16CatalogoTrabajadores AS t16
                JOIN t79AsignacionRepartidorVehiculo AS t79 
                    ON t16.id_Trabajador = t79.Id_Trabajador
                JOIN t40OrdenAsignacionReparto AS t40
                    ON t79.Id_AsignacionRepartidorVehiculo = t40.Id_AsignacionRepartidorVehiculo
                JOIN t401DetalleAsignacionReparto AS t401
                    ON t40.Id_OrdenAsignacion = t401.Id_OrdenAsignacion
                JOIN t59OrdenServicioEntrega AS t59
                    ON t401.Id_OSE = t59.Id_OSE
                JOIN t02OrdenPedido AS t02
                    ON t59.Id_OrdenPedido = t02.Id_OrdenPedido
                JOIN t71OrdenDirecEnvio AS t71
                    ON t02.Id_OrdenPedido = t71.Id_OrdenPedido
                JOIN t77DistritoEnvio AS t77
                    ON t71.Id_Distrito = t77.Id_Distrito
                WHERE t16.id_Trabajador = :idTrabajador";

        // Si se envía un distrito específico, se filtra también por nombre de distrito
        if ($distritoSeleccionado) {
            $sql .= " AND t77.DescNombre = :distrito";
        }

        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idTrabajador', $idTrabajador);
        if ($distritoSeleccionado) {
            $stmt->bindParam(':distrito', $distritoSeleccionado);
        }
        $stmt->execute();
        $resultados = $stmt->fetchAll();

        // Agrupar por distrito para facilitar el manejo en el frontend
        $direcciones_por_distrito = [];
        foreach ($resultados as $fila) {
            $distrito = $fila['Distrito'];
            if (!isset($direcciones_por_distrito[$distrito])) {
                $direcciones_por_distrito[$distrito] = [];
            }
            $direcciones_por_distrito[$distrito][] = $fila['Direccion'];
        }

        echo json_encode([
            'success' => true,
            'data' => $direcciones_por_distrito,
            'raw_data' => $resultados
        ]);
    }
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error al obtener datos: ' . $e->getMessage()
    ]);
}
?>
