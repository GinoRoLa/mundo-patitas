<?php
// Endpoint: Obtener pedidos por dirección (DirecciónSnap)
header('Content-Type: application/json; charset=utf-8');

// Configuración de la base de datos
$host = 'localhost';
$dbname = 'mundo_patitas3';
$username = 'root';
$password = '';

try {
    if (!isset($_GET['direccion']) || $_GET['direccion'] === '') {
        echo json_encode([
            'success' => false,
            'message' => 'Parámetro requerido faltante: direccion'
        ]);
        exit;
    }

    $direccion = $_GET['direccion'];

    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    $sql = "SELECT 
                t02.Id_OrdenPedido,
                t18.NombreProducto,
                t60.Cantidad
            FROM t71OrdenDirecEnvio AS t71
            JOIN t02OrdenPedido AS t02
              ON t71.Id_OrdenPedido = t02.Id_OrdenPedido
            JOIN t60DetOrdenPedido AS t60
              ON t02.Id_OrdenPedido = t60.t02OrdenPedido_Id_OrdenPedido
            JOIN t18CatalogoProducto AS t18
              ON t60.t18CatalogoProducto_Id_Producto = t18.Id_Producto
            WHERE t71.DireccionSnap = :direccion";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':direccion', $direccion);
    $stmt->execute();
    $rows = $stmt->fetchAll();

    echo json_encode([
        'success' => true,
        'data' => $rows
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error al obtener pedidos: ' . $e->getMessage()
    ]);
}
?>

