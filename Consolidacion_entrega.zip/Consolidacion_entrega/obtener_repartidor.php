<?php
// Archivo para obtener datos del repartidor
header('Content-Type: application/json; charset=utf-8');

// Configuración de la base de datos
$host = 'localhost';
$dbname = 'mundo_patitas3';
$username = 'root';
$password = '';

try {
    // Conexión a la base de datos
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Consulta para obtener datos del repartidor
    $sql = "SELECT 
                id_Trabajador, 
                des_nombreTrabajador, 
                des_apepatTrabajador
            FROM t16CatalogoTrabajadores
            WHERE cargo = 'Repartidor'
              AND id_Trabajador = 50008";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $repartidor = $stmt->fetch();
    
    if ($repartidor) {
        echo json_encode([
            'success' => true,
            'data' => $repartidor
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'No se encontró el repartidor'
        ]);
    }
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error al obtener datos del repartidor: ' . $e->getMessage()
    ]);
}
?>
