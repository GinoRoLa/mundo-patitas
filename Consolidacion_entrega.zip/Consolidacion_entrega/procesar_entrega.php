<?php
// Configuración de la base de datos para XAMPP
$host = 'localhost';
$dbname = 'mundo_patitas3';
$username = 'root';
$password = '';

// Configurar headers para JSON
header('Content-Type: application/json; charset=utf-8');

try {
    // Conexión a la base de datos
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error de conexión a la base de datos: ' . $e->getMessage()
    ]);
    exit;
}

// Función para subir imágenes
function subirImagen($archivo, $tipo) {
    $directorio = "uploads/";
    
    // Crear directorio si no existe
    if (!file_exists($directorio)) {
        if (!mkdir($directorio, 0755, true)) {
            return false;
        }
    }
    
    // Validar que sea una imagen
    $extensionesPermitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
    
    if (!in_array($extension, $extensionesPermitidas)) {
        return false;
    }
    
    // Generar nombre único
    $nombreArchivo = $tipo . '_' . uniqid() . '_' . date('Y-m-d_H-i-s') . '.' . $extension;
    $rutaCompleta = $directorio . $nombreArchivo;
    
    // Verificar tamaño (máximo 5MB)
    if ($archivo['size'] > 5 * 1024 * 1024) {
        return false;
    }
    
    if (move_uploaded_file($archivo['tmp_name'], $rutaCompleta)) {
        return $rutaCompleta;
    }
    return false;
}

// Procesar el formulario cuando se envía
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validar datos requeridos
        $campos_requeridos = [
            'repartidorId', 'repartidorNombre', 'repartidorApellido',
            'clienteDni', 'clienteNombre', 'clienteApellidoPaterno',
            'estadoEntrega'
        ];
        
        foreach ($campos_requeridos as $campo) {
            if (empty($_POST[$campo])) {
                echo json_encode([
                    'success' => false,
                    'message' => "El campo $campo es requerido"
                ]);
                exit;
            }
        }
        
        // Obtener y limpiar datos del formulario
        $repartidor_id = trim($_POST['repartidorId']);
        $repartidor_nombre = trim($_POST['repartidorNombre']);
        $repartidor_apellido = trim($_POST['repartidorApellido']);
        $distrito = $_POST['distritoSeleccionado'] ?? '';
        $direccion_seleccionada = trim($_POST['direccionSeleccionada'] ?? '');
        
        // Datos del cliente
        $cliente_dni = trim($_POST['clienteDni']);
        $cliente_nombre = trim($_POST['clienteNombre']);
        $cliente_apellido_paterno = trim($_POST['clienteApellidoPaterno']);
        $cliente_apellido_materno = trim($_POST['clienteApellidoMaterno'] ?? '');
        $cliente_celular = trim($_POST['clienteCelular'] ?? '');
        $cliente_email = trim($_POST['clienteEmail'] ?? '');
        $cliente_direccion = trim($_POST['clienteDireccion'] ?? '');
        
        // Estado y observaciones
        $estado_entrega = $_POST['estadoEntrega'];
        $observaciones = trim($_POST['observaciones'] ?? '');
        
        // Procesar imágenes
        $ruta_foto_direccion = '';
        $ruta_foto_dni = '';
        $ruta_foto_entrega = '';
        $errores_imagenes = [];
        
        if (isset($_FILES['fotoDireccion']) && $_FILES['fotoDireccion']['error'] === 0) {
            $ruta_foto_direccion = subirImagen($_FILES['fotoDireccion'], 'direccion');
            if (!$ruta_foto_direccion) {
                $errores_imagenes[] = 'Error al subir foto de dirección';
            }
        }
        
        if (isset($_FILES['fotoDni']) && $_FILES['fotoDni']['error'] === 0) {
            $ruta_foto_dni = subirImagen($_FILES['fotoDni'], 'dni');
            if (!$ruta_foto_dni) {
                $errores_imagenes[] = 'Error al subir foto del DNI';
            }
        }
        
        if (isset($_FILES['fotoEntrega']) && $_FILES['fotoEntrega']['error'] === 0) {
            $ruta_foto_entrega = subirImagen($_FILES['fotoEntrega'], 'entrega');
            if (!$ruta_foto_entrega) {
                $errores_imagenes[] = 'Error al subir foto de entrega';
            }
        }
        
        // Obtener pedidos seleccionados
        $pedidos_entregar = $_POST['pedidosEntregar'] ?? [];
        
        // Insertar en la base de datos
        $sql = "INSERT INTO entregas (
            repartidor_id, repartidor_nombre, repartidor_apellido,
            distrito, direccion_seleccionada,
            cliente_dni, cliente_nombre, cliente_apellido_paterno, 
            cliente_apellido_materno, cliente_celular, cliente_email, cliente_direccion,
            estado_entrega, observaciones,
            foto_direccion, foto_dni, foto_entrega,
            pedidos_entregar, fecha_creacion
        ) VALUES (
            :repartidor_id, :repartidor_nombre, :repartidor_apellido,
            :distrito, :direccion_seleccionada,
            :cliente_dni, :cliente_nombre, :cliente_apellido_paterno,
            :cliente_apellido_materno, :cliente_celular, :cliente_email, :cliente_direccion,
            :estado_entrega, :observaciones,
            :foto_direccion, :foto_dni, :foto_entrega,
            :pedidos_entregar, NOW()
        )";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':repartidor_id' => $repartidor_id,
            ':repartidor_nombre' => $repartidor_nombre,
            ':repartidor_apellido' => $repartidor_apellido,
            ':distrito' => $distrito,
            ':direccion_seleccionada' => $direccion_seleccionada,
            ':cliente_dni' => $cliente_dni,
            ':cliente_nombre' => $cliente_nombre,
            ':cliente_apellido_paterno' => $cliente_apellido_paterno,
            ':cliente_apellido_materno' => $cliente_apellido_materno,
            ':cliente_celular' => $cliente_celular,
            ':cliente_email' => $cliente_email,
            ':cliente_direccion' => $cliente_direccion,
            ':estado_entrega' => $estado_entrega,
            ':observaciones' => $observaciones,
            ':foto_direccion' => $ruta_foto_direccion,
            ':foto_dni' => $ruta_foto_dni,
            ':foto_entrega' => $ruta_foto_entrega,
            ':pedidos_entregar' => json_encode($pedidos_entregar)
        ]);
        
        // Respuesta exitosa
        $mensaje = 'Entrega registrada exitosamente';
        if (!empty($errores_imagenes)) {
            $mensaje .= '. Advertencias: ' . implode(', ', $errores_imagenes);
        }
        
        echo json_encode([
            'success' => true,
            'message' => $mensaje,
            'id' => $pdo->lastInsertId(),
            'imagenes' => [
                'direccion' => $ruta_foto_direccion,
                'dni' => $ruta_foto_dni,
                'entrega' => $ruta_foto_entrega
            ]
        ]);
        
    } catch (Exception $e) {
        // Error en el procesamiento
        echo json_encode([
            'success' => false,
            'message' => 'Error al procesar la entrega: ' . $e->getMessage()
        ]);
    }
} else {
    // Si no es POST, devolver error
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido'
    ]);
}
?>
