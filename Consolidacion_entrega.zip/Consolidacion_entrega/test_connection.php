<?php
// Archivo de prueba para verificar la conexión a la base de datos
header('Content-Type: text/html; charset=utf-8');

echo "<h2>Prueba de Conexión a Base de Datos</h2>";

// Configuración de la base de datos
$host = 'localhost';
$dbname = 'mundo_patitas3';
$username = 'root';
$password = '';

try {
    // Conexión a la base de datos
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<p style='color: green;'>✅ Conexión exitosa a la base de datos</p>";
    
    // Verificar si existen las tablas necesarias
    $tablas_requeridas = ['t70DireccionEnvioCliente', 't77DistritoEnvio'];
    $tablas_existentes = [];
    
    foreach ($tablas_requeridas as $tabla) {
        $stmt = $pdo->query("SHOW TABLES LIKE '$tabla'");
        if ($stmt->rowCount() > 0) {
            echo "<p style='color: green;'>✅ Tabla '$tabla' existe</p>";
            $tablas_existentes[] = $tabla;
        } else {
            echo "<p style='color: red;'>❌ Tabla '$tabla' no existe</p>";
        }
    }
    
    // Si las tablas existen, mostrar datos de prueba
    if (count($tablas_existentes) == 2) {
        echo "<h3>Datos de prueba de direcciones y distritos:</h3>";
        
        $sql = "SELECT 
                    t77.DescNombre AS Distritos,
                    t70.Direccion AS Direcciones
                FROM t70DireccionEnvioCliente AS t70
                INNER JOIN t77DistritoEnvio AS t77
                    ON t70.Id_Distrito = t77.Id_Distrito
                LIMIT 10";
        
        $stmt = $pdo->query($sql);
        $resultados = $stmt->fetchAll();
        
        if (count($resultados) > 0) {
            echo "<table border='1' style='border-collapse: collapse;'>";
            echo "<tr><th>Distrito</th><th>Dirección</th></tr>";
            foreach ($resultados as $fila) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($fila['Distritos']) . "</td>";
                echo "<td>" . htmlspecialchars($fila['Direcciones']) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p style='color: orange;'>⚠️ No hay datos en las tablas</p>";
        }
    }
    
    // Verificar permisos de carpeta uploads
    if (is_dir('uploads')) {
        if (is_writable('uploads')) {
            echo "<p style='color: green;'>✅ Carpeta 'uploads' existe y es escribible</p>";
        } else {
            echo "<p style='color: orange;'>⚠️ Carpeta 'uploads' existe pero no es escribible</p>";
        }
    } else {
        echo "<p style='color: orange;'>⚠️ Carpeta 'uploads' no existe. Se creará automáticamente</p>";
    }
    
} catch(PDOException $e) {
    echo "<p style='color: red;'>❌ Error de conexión: " . $e->getMessage() . "</p>";
    echo "<p>Verifica que:</p>";
    echo "<ul>";
    echo "<li>XAMPP esté ejecutándose</li>";
    echo "<li>MySQL esté activo</li>";
    echo "<li>La base de datos 'consolidacion_entregas' exista</li>";
    echo "<li>Los datos de conexión sean correctos</li>";
    echo "</ul>";
}

echo "<hr>";
echo "<p><a href='consolidacion_entrega.html'>← Volver al formulario</a></p>";
?>
